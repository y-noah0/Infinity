import Footer from "../../Defaults/Footer/Footer";
import Navigation from "../../Defaults/Navigation/Navigation";

// import style from './Register.module.css';
function Register() {
    return(
        <>
        <Navigation/>
        <div>
            <h1>Register</h1>
        </div>
        <Footer/>
        </>
    )
}
export default Register;