import Footer from "../../Defaults/Footer/Footer";
import Navigation from "../../Defaults/Navigation/Navigation";

// import style from './SignIn.module.css';
function SignIn() {
    return(
        <>
        <Navigation/>
        <div>
            <h1>SignIn</h1>
        </div>
        <Footer/>
        </>
    )
}
export default SignIn;