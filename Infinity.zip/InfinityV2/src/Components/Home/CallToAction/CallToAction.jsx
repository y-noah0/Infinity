// import style from './CallToAction.module.css';

function CallToAction() {
    return(
        <div>
            <h1>CallToAction</h1>
        </div>
    )
}
export default CallToAction;