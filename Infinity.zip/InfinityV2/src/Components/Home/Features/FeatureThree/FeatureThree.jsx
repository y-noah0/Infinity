//import style from './FeatureThree.module.css';
function FeatureThree() {
    return(
        <div>
            <h1>FeatureThree</h1>
        </div>
    )
}
export default FeatureThree;