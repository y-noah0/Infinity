import FeatureOne from "./FeatureOne/FeatureOne";
import FeatureThree from "./FeatureThree/FeatureThree";
import FeatureTwo from "./FeatureTwo/FeatureTwo";

function Features(){
    return(
        <>
        <FeatureOne/>
        <FeatureTwo/>
        <FeatureThree/>
        </>
    )
}

export default Features;