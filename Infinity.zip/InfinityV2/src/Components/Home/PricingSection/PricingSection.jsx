// import style from './PricingSection.module.css';
function PricingSection() {
    return(
        <div>
            <h1>PricingSection</h1>
        </div>
    )
}
export default PricingSection;