import Footer from "../Defaults/Footer/Footer";
import Navigation from "../Defaults/Navigation/Navigation";

// import style from './Pricing.module.css';
function Pricing() {
    return(
        <div>
            <Navigation/>
            <h1>Pricing</h1>
            <Footer/>
        </div>
    )
}
export default Pricing;